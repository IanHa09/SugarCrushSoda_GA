# Game Structure Survey

이 문서는 `game_survey.jsonl`의 화면 캡처와 구조화된 조사 기록으로 생성되었습니다.

## Overview

- Survey records: 134
- Unique screen signatures: 134
- Navigation nodes: 10 (화면 타입별: event_or_mission 1, help_support 2, playing_board 1, reward_popup 1, shop_or_currency 1, social_friends 4)
- ⚠️ 화면 파편화 의심: Friends / Social 4개 (기준 3개 이상). 실제로 서로 다른 화면이면 무시해도 되고, 같은 화면이 쪼개진 것이면 아래 Screen Hierarchy에서 대표 이미지를 비교해 확인하세요.

## Game Structure Diagram

Autodrive가 관찰한 실제 화면 전환입니다. 실선은 루트에서 BFS로 만든 계층(트리), 점선은 트리에 들어가지 않은 교차 링크입니다.

```mermaid
flowchart LR
    screen_screen_8faa35c7e3e1["Playing Board"]
    screen_screen_edb1e3470b04["Reward Popup"]
    screen_screen_d2762a7f2eb4["Help / Support"]
    screen_screen_45adce5928e4["Help / Support"]
    screen_screen_3e55132b8e0b["Shop / Currency"]
    screen_screen_d96a2858202f["Friends / Social"]
    screen_screen_69fc32470ead["Friends / Social"]
    screen_screen_dfb3800771a8["Friends / Social"]
    screen_screen_29ca108cd13f["Event / Mission"]
    screen_screen_18c5c1774ede["Friends / Social"]
    screen_level_start["Level Start (survey only)"]
    screen_screen_8faa35c7e3e1 -->|"+5"| screen_screen_edb1e3470b04
    screen_screen_8faa35c7e3e1 -->|"!"| screen_screen_3e55132b8e0b
    screen_screen_8faa35c7e3e1 -->|"친구 목록"| screen_screen_d96a2858202f
    screen_screen_edb1e3470b04 -->|"친구에게 요청"| screen_screen_d2762a7f2eb4
    screen_screen_d96a2858202f -->|"친구 더 추가"| screen_screen_69fc32470ead
    screen_screen_d96a2858202f -->|"정보 아이콘"| screen_screen_29ca108cd13f
    screen_screen_d96a2858202f -->|"?"| screen_screen_18c5c1774ede
    screen_screen_d2762a7f2eb4 -->|"친구에게 요청하기"| screen_screen_45adce5928e4
    screen_screen_69fc32470ead -->|"초대하기"| screen_screen_dfb3800771a8
    screen_screen_3e55132b8e0b -.->|"소셜 아이콘"| screen_screen_d96a2858202f
    screen_screen_69fc32470ead -.->|"뒤로(키)"| screen_screen_d96a2858202f
    screen_screen_29ca108cd13f -.->|"확인"| screen_screen_d96a2858202f
    screen_screen_18c5c1774ede -.->|"확인"| screen_screen_d96a2858202f
    screen_screen_45adce5928e4 -.->|"보내기"| screen_screen_8faa35c7e3e1
    screen_screen_dfb3800771a8 -.->|"닫기"| screen_screen_69fc32470ead
```

연결선은 실제 전환, `survey only`는 조사 기록에만 있는 화면입니다.

## Screen Hierarchy

루트에서 BFS로 투영한 화면 계층입니다.

- **Playing Board** (`playing_board`, visits=6)
  - Evidence: navigation/representatives/screen_8faa35c7e3e1.png
  - **Reward Popup** (`reward_popup`, visits=1) — via '+5'
    - Evidence: navigation/representatives/screen_edb1e3470b04.png
    - **Help / Support** (`help_support`, visits=1) — via '친구에게 요청'
      - Evidence: navigation/representatives/screen_d2762a7f2eb4.png
      - **Help / Support** (`help_support`, visits=1) — via '친구에게 요청하기'
        - Evidence: navigation/representatives/screen_45adce5928e4.png
  - **Shop / Currency** (`shop_or_currency`, visits=48) — via '!'
    - Evidence: navigation/representatives/screen_3e55132b8e0b.png
  - **Friends / Social** (`social_friends`, visits=70) — via '친구 목록'
    - Evidence: navigation/representatives/screen_d96a2858202f.png
    - **Friends / Social** (`social_friends`, visits=4) — via '친구 더 추가'
      - Evidence: navigation/representatives/screen_69fc32470ead.png
      - **Friends / Social** (`social_friends`, visits=1) — via '초대하기'
        - Evidence: navigation/representatives/screen_dfb3800771a8.png
    - **Event / Mission** (`event_or_mission`, visits=1) — via '정보 아이콘'
      - Evidence: navigation/representatives/screen_29ca108cd13f.png
    - **Friends / Social** (`social_friends`, visits=1) — via '?'
      - Evidence: navigation/representatives/screen_18c5c1774ede.png
      
* b4와 04는 화면은 다른게 맞으나, 가운데의 버튼이름이 같아 같은 이름으로 표시됨.
### Cross Links (트리 밖 간선)

- **Shop / Currency** (`shop_or_currency`, visits=48) --(소셜 아이콘)--> **Friends / Social** (`social_friends`, visits=70)
- **Friends / Social** (`social_friends`, visits=4) --(뒤로(키))--> **Friends / Social** (`social_friends`, visits=70)
- **Event / Mission** (`event_or_mission`, visits=1) --(확인)--> **Friends / Social** (`social_friends`, visits=70)
- **Friends / Social** (`social_friends`, visits=1) --(확인)--> **Friends / Social** (`social_friends`, visits=70)
- **Help / Support** (`help_support`, visits=1) --(보내기)--> **Playing Board** (`playing_board`, visits=6)
- **Friends / Social** (`social_friends`, visits=1) --(닫기)--> **Friends / Social** (`social_friends`, visits=4)

## Exploration Frontier

- 탐색 커버리지: 26/76 ((화면,행동) 조합 기준, 눌러본 것/발견한 것, 누르지 않고 정리된 것 39개)

### 아직 안 눌러본 프론티어

- **Shop / Currency**: 스타 아이콘, 헬프 기호
- **Help / Support**: 닫기
- **Playing Board**: 뒤로가기 버튼, 별 버튼, 상점, 아이템 박스, 점수 목표, 프로필, 확인 버튼
- **Help / Support**: 닫기

### 도달 실패로 포기함(blocked)

- **Event / Mission**: 닫기
- **Reward Popup**: 닫기

### 다시 봐도 후보에 안 나와 정리함(not_visible)

- **Shop / Currency**: 12시간, 12시간 할인, 45코인, 격일 할인, 골드 특가, 골드 특가 클릭, 다음, 닫기, 더 보기, 뒤로, 랭킹, 상태 표시, 일정, 작은 스낵!, 장바구니, 조정, 주간 할인, 주간 할인 정보, 주간 할인 클릭, 추가 항목, 친구 추가, 특별 상품, 특별 상품 클릭, 특별 혜택, 하정 혜택!, 한정, 한정 혜택!, 할인, 할인 보기, 할인 혜택!
- **Friends / Social**: 메시지함, 친구, 홈
- **Playing Board**: 레벨도, 부스터
- **Friends / Social**: info, 돋보기 아이콘, 하트 상징 아이콘, 하트 아이콘

### 누르기 전 확대 확인에서 못 찾아 정리함(not_found)

- **Shop / Currency**: Claim, 시작하기, 주간 보상 버튼, 특별 상품 정보, 프로필, 확인
- **Playing Board**: 부스터 선택
- **Friends / Social**: 메시지 아이콘

## Screen Types

- **event_or_mission**: 친구와 함께하면 즐거움이 더해진다는 내용의 안내 화면으로, 친구 추가와 관련된 기능 설명이 포함됨.
  - Evidence: ../../../captures/2026-10-02_09-19-55_643787_survey_raw.png
- **help_support**: 친구에게 하트를 요청하는 도움 받기 팝업.
  - Evidence: ../../../captures/2026-10-02_09-08-27_533769_survey_raw.png
- **level_start**: 레벨 시작 화면으로, 플레이어의 진행 상태와 목표를 나타냄.
  - Evidence: ../../../captures/2026-10-02_09-09-00_917194_survey_raw.png
- **playing_board**: 게임의 보드 플레이 화면으로, 플레이어가 현재 레벨을 진행 중임을 나타냄.
  - Evidence: ../../../captures/2026-10-02_09-08-10_892850_survey_raw.png
- **reward_popup**: 보상 팝업 화면으로 하트가 축적되었음을 알림.
  - Evidence: ../../../captures/2026-10-02_09-08-18_783094_survey_raw.png
- **shop_or_currency**: 상점 화면으로, 여러 아이템을 구매할 수 있는 옵션을 제공함. 특별 상품과 골드 특가가 포함됨.
  - Evidence: ../../../captures/2026-10-02_09-09-17_801745_survey_raw.png
- **social_friends**: 친구 화면으로, 친구 추가와 메시지 기능이 포함됨.
  - Evidence: ../../../captures/2026-10-02_09-17-58_098249_survey_raw.png

## Game Elements

이름이 같으면 분류가 달라도 한 항목으로 묶었습니다. 대표 이름은 가장 자주 나온 표기, 대표 분류는 가장 자주 붙은 분류이고, 다른 분류에도 기록됐으면 옆에 적었습니다. 등장 화면은 두 화면 이상일 때만 적습니다.

### booster
- small_snacks
- 부스터 — 2개 화면: Playing Board, Shop / Currency
- 부스터 상품
- 소셜 보너스
- 스낵
- 작은 스낵 (분류 중복: core_play, monetization)
- 친구 더 추가하기 버튼
- 하트 전송 보조 기능

### character
- 게임 캐릭터
- 인물 그래픽
- 인어 캐릭터
- 주요 캐릭터
- 주인공 캐릭터
- 캐릭터 (분류 중복: other) — 2개 화면: Friends / Social, Playing Board
- 캐릭터 (인어)
- 캐릭터 아바타
- 캐릭터 일러스트
- 캐릭터와 하트
- 플레이어 캐릭터 (분류 중복: core_play)
- 하트 캐릭터

### core_play
- 게임 경험
- 게임 진행 안내
- 도움 요청 기능 (분류 중복: objective) — 2개 화면: Friends / Social, Playing Board
- 레벨 진행 상태 (분류 중복: progression)
- 레벨 표시 (분류 중복: progression)
- 점수 아이콘
- 플레이어 안내

### currency
- gold_currency
- 가격 (분류 중복: monetization, ui)
- 가격표
- 게임 화폐
- 골드 (분류 중복: monetization) — 2개 화면: Playing Board, Shop / Currency
- 골드 아이템 (분류 중복: monetization)
- 금
- 금고
- 금괴
- 단위
- 상점 구매화폐
- 상점 아이템 (분류 중복: ui)
- 상점 코인
- 상점 화폐
- 상품기록
- 소지금 표시
- 스낵 아이템 (분류 중복: reward)
- 시간 제한 아이템
- 아이템 가격 (분류 중복: ui)
- 얼마나 사용할 수 있는가
- 잔액 표시
- 재화 — 2개 화면: Playing Board, Shop / Currency
- 재화 요구
- 코인 (분류 중복: ui) — 2개 화면: Playing Board, Shop / Currency
- 특별 상품 가격

### monetization
- 2+1 프로모션
- discount_offer
- special_items
- 골드 특가 (분류 중복: booster, core_play, reward)
- 구매 가격 (분류 중복: currency)
- 구매 가능 상품
- 구매 버튼 (분류 중복: currency, ui)
- 상점아이템
- 상품 리스트
- 소비 아이템
- 아이템 구매 (분류 중복: ui)
- 작은 스낵 아이템
- 주간 할인 (분류 중복: booster, core_play, other, progression, reward)
- 특별 상품 (분류 중복: booster, core_play, currency, objective, reward)
- 패키지 구매
- 한정 혜택 (분류 중복: reward)
- 할인 상품 (분류 중복: booster, currency, reward)
- 할인 정보
- 할인 혜택 (분류 중복: currency)

### objective
- SNS 증대
- 게임 경험 향상
- 게임 목적 안내
- 기능 설명
- 레벨 목표
- 레벨 목표 정보
- 목표 안내
- 미션 아이콘
- 점수 목표
- 친구와의 상호작용 안내
- 친구와의 플레이 이점
- 하정 혜택 안내
- 하트 보내기 (분류 중복: reward)
- 할인 제공
- 흔적 설명

### obstacle
- 장애물 아이콘
- 장애물/데코레이션
- 특정 아이콘

### other
- 문구 강조
- 소셜 아이콘
- 스타 아이콘
- 코멘트 안내
- 할인 (분류 중복: reward)
- 헬프 기호

### progression
- 별 등급
- 보내기 버튼
- 주문 버튼

### reward
- 상금 아이콘
- 소셜 보상 안내
- 아이템 상자

### social
- 메시지함 (분류 중복: ui)
- 소다 플레이어 (분류 중복: character)
- 연락처
- 친구 리스트
- 친구 목록 (분류 중복: core_play, ui) — 2개 화면: Friends / Social, Help / Support
- 친구 요청 버튼
- 친구 초대 — 2개 화면: Friends / Social, Playing Board
- 친구 추가 및 도움 기능
- 친구 추가 버튼 (분류 중복: booster, core_play, objective, other, progression, ui)
- 친구 추천 설명
- 하트 선물
- 하트 송신 기능
- 하트 전송 기능 (분류 중복: booster, objective, reward, ui)

### ui
- 구분선
- 기본 정보
- 깨기 버튼
- 메뉴
- 메뉴 탭
- 메시지 기능 (분류 중복: social)
- 메시지 탭
- 메시지탭
- 메시지함 내비게이션
- 메시지함 탭 (분류 중복: social)
- 메인 탭
- 버튼 — 2개 화면: Friends / Social, Shop / Currency
- 상점 메뉴
- 상점 버튼 (분류 중복: monetization)
- 상점 탭
- 선택 버튼
- 설정 버튼 — 2개 화면: Playing Board, Shop / Currency
- 소셜 메시지
- 시간 표시
- 아이콘
- 안내 문구
- 요청 버튼
- 정보 아이콘
- 정보탭
- 제한 시간 표시
- 조작 버튼
- 초대하기 버튼
- 친구 메뉴 탭
- 친구 와 함께하는 메시지
- 친구 탭
- 친구탭
- 탭
- 탭 메뉴
- 하단 네비게이션 바
- 하트 아이콘 (분류 중복: core_play, currency, reward, social) — 3개 화면: Friends / Social, Playing Board, Reward Popup
- 하트 요청 팝업
- 홈 버튼
- 확인 버튼
- 회색 배경

## Button And Navigation Candidates

### progression
- 친구에게 요청 (confidence=1.00) - 다음 단계로 진행하는 버튼.
- 친구에게 요청하기 (confidence=1.00) - 하트를 요청하기 위한 진행 버튼.
- 보내기 (confidence=0.95) - 하트를 요청하기 위한 진행 버튼
- 10 (confidence=0.90) - 현재 레벨 번호 표시.
- 확인 (confidence=0.85) - 상점 상품 구매 진행 버튼
- 주간 할인 (confidence=0.85) - 할인 상품을 보기 위한 버튼.
- 골드 특가 (confidence=0.75) - 특가 상품을 보기 위한 버튼.
- Claim (confidence=0.85) - 보상 획득 버튼으로 진행을 위한 후보.
- 시작하기 (confidence=0.80) - 상점에서의 새로운 화면으로 넘어가는 버튼.
- 다음 (confidence=0.85) - 다음 단계로 진행하는 버튼.
- 특별 상품 클릭 (confidence=0.80) - 특별 상품 선택을 위한 버튼.
- 주간 할인 클릭 (confidence=0.85) - 주간 할인 선택을 위한 버튼.
- 골드 특가 클릭 (confidence=0.85) - 골드 특가 선택을 위한 버튼.
- 친구 더 추가 (confidence=0.90) - 친구 추가를 위한 진행 버튼
- 초대하기 (confidence=0.90) - 다음 단계로 진행하는 버튼
- 친구 더 추가하기 (confidence=0.90) - 사용자가 친구를 추가하기 위한 버튼.
- 점수 목표 (confidence=0.90) - 다음 목표 달성을 위해 필요.
- 확인 버튼 (confidence=0.90) - 게임 진행을 위한 버튼.
- 별 버튼 (confidence=0.80) - 다음 단계로 진행할 수 있는 버튼
- 친구 추가 (confidence=0.90) - 진행을 위한 버튼.

### risky_account
- 구매일로부터 7일 내 청약 철회 가능 (confidence=0.70) - 구매 관련 정보 제공
- 초대하기 (confidence=0.85) - 친구 초대 버튼, 권한 요청 가능성 우려.
- 게임 시작하기 버튼 (confidence=0.80) - 게임 진행을 위한 버튼이지만 로그인 요청 포함.

### risky_monetization
- 구매하기 (confidence=0.90) - 아이템 구매를 위한 버튼으로 보임.
- 혜택 보기 (confidence=0.90) - 특별 할인 혜택 보기 버튼.
- ₩5,500 (confidence=0.90) - 구매 버튼으로 보이는 가격 표시.
- 한정 혜택! (confidence=0.80) - 특별한 구매 제안을 나타내는 버튼.
- 골드 특가 (confidence=0.95) - 구매를 유도하는 특가 상품.
- 구매 (confidence=0.92) - 구매 유도 버튼.
- 특별 상품 구입 (confidence=0.90) - 특별 상품 구매 버튼.
- 12시간 (confidence=0.80) - 특정 할인 안내 버튼
- 습관 해택! (confidence=0.85) - 특정 패키지 구매를 제안하는 버튼.
- 하나의 혜택! (confidence=0.90) - 특정 패키지를 구매하기 위한 안내입니다.
- 작은 스낵! (confidence=0.80) - 구매할 수 있는 스낵 항목.
- 100% 할인가격 (confidence=0.85) - 할인 관련 구매 버튼.
- 구입 (confidence=0.90) - 아이템을 구입할 수 있는 버튼.
- 구매 버튼 (confidence=0.90) - 구매를 위한 버튼으로, 실제 구매와 관련된 기능.
- 할인 혜택! (confidence=0.90) - 할인 혜택을 제공하는 버튼

### safe_navigation
- 홈 (confidence=0.80) - 플레이어가 홈 화면으로 이동할 수 있는 버튼.
- 닫기 (confidence=1.00) - 팝업닫기 버튼.
- ! (confidence=0.90) - 도움을 요청하는 아이콘.
- 상점 열기 (confidence=0.80) - 상점으로 돌아가기 위한 버튼.
- 상점 (confidence=0.95) - 상점으로 돌아가는 버튼.
- 뒤로 (confidence=0.90) - 상점에서 빠져나가기 위한 버튼.
- 상태 표시 (confidence=0.85) - 상태 메시지 표시.
- 더 보기 (confidence=0.90) - 상품 목록 추가 열람.
- 상점 아이콘 (confidence=0.90) - 상점으로의 탐색 버튼
- 상점 메뉴 (confidence=0.70) - 상점으로 돌아가기 위한 네비게이션 버튼.
- 헬프 기호 (confidence=0.90) - 고객 도움말로 이동하는 버튼.
- 상점 로고 (confidence=0.90) - 상점으로 이동하는 버튼.
- 친구 (confidence=0.80) - 친구 리스트로 돌아가는 버튼.
- 메시지함 (confidence=0.80) - 메시지함으로 이동하는 버튼.
- 정보 아이콘 (confidence=0.70) - 게임 정보로 이동하는 버튼.
- info (confidence=0.80) - 정보로 이동하는 버튼.
- 정보 (confidence=0.80) - 게임 옵션을 보여주는 버튼.
- 정보 버튼 (confidence=0.80) - 게임 정보로 이동하는 버튼.
- 뒤로가기 버튼 (confidence=0.95) - 이전 화면으로 돌아가기 위한 버튼.
- 친구 추가 (confidence=0.90) - 친구 추가 기능으로 UI 이동을 위한 버튼.

### structure
- +5 (confidence=0.80) - 하트를 추가하는 버튼, 구조적 요소.
- +50 (confidence=0.80) - 골드 추가 버튼, 구조적 요소.
- 레벨도 (confidence=0.80) - 현재 레벨 안내 버튼.
- 부스터 (confidence=0.60) - 부스터 선택 UI.
- 8 (confidence=0.90) - 앞선 레벨 별 등급 표시.
- 9 (confidence=0.90) - 앞선 레벨 별 등급 표시.
- ! (confidence=1.00) - 하트를 요청하는 도움 버튼
- 홈 (confidence=0.90) - 메인 화면으로 돌아가는 버튼
- 상점 (confidence=0.95) - 상점으로 가는 버튼, 게임 구조에 중요한 역할.
- 주간 할인 (confidence=0.85) - 주간 할인 섹션 안내.
- 특별 상품 (confidence=0.90) - 특별 상품 목록 표시.
- 작은 스낵! (confidence=0.90) - 아이템 설명.
- 골드 특가 (confidence=0.90) - 골드 특가 프로모션 안내.
- 12시간 (confidence=0.85) - 특별 상품에 대한 시간 정보를 나타내는 버튼.
- 45코인 (confidence=0.70) - 상점에서 사용 가능 코인 수.
- 할인 (confidence=0.80) - 주간 할인을 나타냄.
- 12시간 할인 (confidence=0.70) - 특별 할인 정보.
- 할인 혜택! (confidence=0.85) - 할인 정보.
- 프로필 (confidence=0.80) - 사용자 프로필을 보는 버튼.
- 추가 항목 (confidence=0.70) - 더 많은 아이템을 확인하는 버튼.
- 조정 (confidence=0.75) - 설정 관련 요소일 가능성
- 한정 (confidence=0.80) - 한정 혜택 반영 부분
- 하정 혜택! (confidence=0.80) - 하정 혜택 안내 메시지.
- 친구 추가 (confidence=0.85) - 친구 기능으로 이동하는 버튼.
- 랭킹 (confidence=0.85) - 랭킹 보기 버튼.
- 일정 (confidence=0.85) - 일정 보기 버튼.
- 격일 할인 (confidence=0.90) - 할인 내용 표시.
- 장바구니 (confidence=0.75) - 장바구니 아이콘으로 구매 내역 확인 가능.
- 상점 메뉴 (confidence=0.90) - 상점의 메뉴바.
- 할인 보기 (confidence=0.75) - 할인 상품 보기 버튼.
- 특별 혜택 (confidence=0.70) - 특별 혜택 섹션.
- 한정 혜택! (confidence=0.85) - 한정 상품에 대한 안내 버튼.
- 주간 보상 버튼 (confidence=0.80) - 주간 보상을 확인하는 메뉴 버튼
- 상점 클릭 (confidence=0.90) - 상점을 여는 버튼으로 위치가 확인됨.
- 특별 상품 정보 (confidence=0.80) - 특별 상품 섹션을 보여주는 버튼.
- 주간 할인 정보 (confidence=0.80) - 주간 할인 섹션이 포함된 버튼.
- 소셜 아이콘 (confidence=0.90) - 친구 목록 및 소셜 기능으로 이동.
- 스타 아이콘 (confidence=0.90) - 레벨 및 업적 확인 기능.
- 친구 (confidence=0.90) - 친구 목록 및 기능 접근을 위한 버튼.
- 메시지함 (confidence=0.90) - 메시지를 확인할 수 있는 기능.
- 친구 탭 (confidence=0.80) - 친구 목록으로 이동하는 버튼.
- 메시지함 탭 (confidence=0.80) - 메시지함으로 이동하기 위한 버튼.
- 친구 아이콘 (confidence=0.90) - 친구 목록으로 이동하기 위한 아이콘.
- 메시지 아이콘 (confidence=0.90) - 메시지 기능으로 이동하기 위한 아이콘.
- 정보 아이콘 (confidence=0.70) - 도움말이나 설명을 위한 정보 아이콘.
- 정보 버튼 (confidence=0.90) - 게임 정보 화면으로 가는 버튼.
- 정보 (confidence=0.90) - 게임 정보 접근을 위한 버튼.
- 하트 아이콘 (confidence=0.80) - 시각적 요소로 친구와의 소통 강조.
- 하트 상징 아이콘 (confidence=0.80) - 하트를 보내주는 기능을 나타내는 아이콘.
- info (confidence=1.00) - 다양한 정보를 제공하는 버튼.
- 돋보기 아이콘 (confidence=0.70) - 검색 기능으로 연결되는 버튼.
- 부스터 선택 (confidence=0.90) - 부스터 아이콘이 보드의 플레이 구조를 보여주기 위해 포함됨.
- 아이템 박스 (confidence=0.85) - 아이템 박스가 플레이 전략과 연결됨.
- 친구 목록 (confidence=0.90) - 친구 목록으로 이동할 수 있는 버튼

### unknown
- ?? (confidence=0.70) - 의문 아이콘으로 기능 미확인.
- 정보 (confidence=0.70) - 단순 정보 버튼으로 추정

## Evidence Index

화면 타입이 바뀌는 지점만 남겼습니다(같은 화면 연속 관찰은 건수로 표시).

- Step 1: playing_board
  - Image: ../../../captures/2026-10-02_09-08-10_892850_survey_raw.png
  - Summary: 게임의 보드 플레이 화면으로, 플레이어가 현재 레벨을 진행 중임을 나타냄.
- Step 2: reward_popup
  - Image: ../../../captures/2026-10-02_09-08-18_783094_survey_raw.png
  - Summary: 보상 팝업 화면으로 하트가 축적되었음을 알림.
- Step 3–4 (2건): help_support
  - Image: ../../../captures/2026-10-02_09-08-27_533769_survey_raw.png
  - Summary: 친구에게 하트를 요청하는 도움 받기 팝업.
- Step 5: playing_board
  - Image: ../../../captures/2026-10-02_09-08-51_699393_survey_raw.png
  - Summary: 게임의 보드 플레이 화면으로, 현재 레벨 정보와 진행 중임을 나타냄.
- Step 6: level_start
  - Image: ../../../captures/2026-10-02_09-09-00_917194_survey_raw.png
  - Summary: 레벨 시작 화면으로, 플레이어의 진행 상태와 목표를 나타냄.
- Step 7: playing_board
  - Image: ../../../captures/2026-10-02_09-09-09_900897_survey_raw.png
  - Summary: 게임의 보드 플레이 화면으로, 현재 레벨과 진행 상태를 나타냄.
- Step 8–34 (27건): shop_or_currency
  - Image: ../../../captures/2026-10-02_09-09-17_801745_survey_raw.png
  - Summary: 상점 화면으로, 여러 아이템을 구매할 수 있는 옵션을 제공함. 특별 상품과 골드 특가가 포함됨.
- Step 1–21 (21건): shop_or_currency
  - Image: ../../../captures/2026-10-02_09-13-51_446770_survey_raw.png
  - Summary: 상점 화면으로, 특별 상품과 다양한 아이템 구매 옵션이 포함됨.
- Step 22–31 (10건): social_friends
  - Image: ../../../captures/2026-10-02_09-17-58_098249_survey_raw.png
  - Summary: 친구 화면으로, 친구 추가와 메시지 기능이 포함됨.
- Step 32: event_or_mission
  - Image: ../../../captures/2026-10-02_09-19-55_643787_survey_raw.png
  - Summary: 친구와 함께하면 즐거움이 더해진다는 내용의 안내 화면으로, 친구 추가와 관련된 기능 설명이 포함됨.
- Step 33–40 (8건): social_friends
  - Image: ../../../captures/2026-10-02_09-20-10_551258_survey_raw.png
  - Summary: 친구 화면으로, 친구 추가와 메시지 기능이 포함됨.
- Step 1–32 (32건): social_friends
  - Image: ../../../captures/2026-10-02_09-21-42_094524_survey_raw.png
  - Summary: 친구 화면으로, 친구 추가와 관련된 안내가 포함됨.
- Step 1–11 (11건): social_friends
  - Image: ../../../captures/2026-10-02_09-27-55_619614_survey_raw.png
  - Summary: 친구와 함께하면 더 즐거운 경험을 강조하는 친구 추가 안내 화면. 최근 기록과 동일한 구조.
- Step 1–11 (11건): social_friends
  - Image: ../../../captures/2026-10-02_09-30-05_115804_survey_raw.png
  - Summary: 친구와 함께하면 더 즐거운 경험을 강조하는 친구 추가 안내 화면으로, 하트 전송 기능이 설명됨. 최근 기록과 동일한 구조.
- Step 1–2 (2건): playing_board
  - Image: ../../../captures/2026-10-02_11-01-39_331122_survey_raw.png
  - Summary: 현재 보드 플레이 화면으로, 다양한 아이템과 점수가 시각적으로 표시되어 있음.
- Step 3–6 (4건): social_friends
  - Image: ../../../captures/2026-10-02_11-01-57_701791_survey_raw.png
  - Summary: 친구 추가 안내 화면으로, 친구와 함께 하면 더 즐겁다는 메시지가 강조되어 있으며, 하트 전송 기능이 설명됨. 최근 기록과 동일한 구조.
