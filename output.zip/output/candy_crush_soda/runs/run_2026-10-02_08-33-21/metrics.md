# 탐색 지표: run_2026-10-02_08-33-21

## 그래프 상태

- nodes: 10
- edges: 15
- self_loop_edges: 0
- unreached_from_root: 0
- coverage: 26/76
- screen_types: {'playing_board': 1, 'reward_popup': 1, 'help_support': 2, 'shop_or_currency': 1, 'social_friends': 4, 'event_or_mission': 1}
- ledger verdicts: {'new_screen': 8, 'not_visible': 39, 'no_change': 3, 'blocked': 2, 'open': 11, 'known_screen': 5, 'not_found': 8}

## 세션별

| 세션 | 스텝 | 탭 | 화면 바뀜 | 그대로 | 적중률 | 재확인 찾음 | 재확인 못찾음 | 보정 중앙값(px) | 뒤로키 | 새 화면 | 누적 화면 | 새 전환 | 누적 전환 | 종료 |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| 1 | 34 | 25 | 5 | 20 | 20% | 13 | 4 | 219.1 | 12 | 5 | 5 | 5 | 5 | unreachable |
| 2 | 40 | 30 | 6 | 24 | 20% | 12 | 4 | 145.7 | 18 | 4 | 9 | 6 | 11 | other(tap_executed) |
| 3 | 32 | 27 | 2 | 25 | 7% | 4 | 0 | 171.6 | 23 | 1 | 10 | 2 | 13 | unreachable |
| 4 | 11 | 10 | 0 | 10 | 0% | 0 | 0 | - | 10 | 0 | 10 | 0 | 13 | unreachable |
| 5 | 11 | 10 | 0 | 10 | 0% | 0 | 0 | - | 10 | 0 | 10 | 0 | 13 | unreachable |
| 6 | 6 | 4 | 1 | 3 | 25% | 1 | 1 | 148.3 | 3 | 0 | 10 | 1 | 14 | unreachable |

- 적중률 = 화면을 실제로 바꾼 탭 / 판정 가능한 탭. 판정 근거(change_source)는 CSV에 있습니다(tap_effect > pixels > screen_id).
- 누적 화면·누적 전환이 세션을 거듭해도 거의 안 늘면 그래프가 수렴한 것입니다.
